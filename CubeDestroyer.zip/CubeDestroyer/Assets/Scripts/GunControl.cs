﻿using UnityEngine;

public class GunControl : MonoBehaviour
{
    [SerializeField] private Camera PlayerCamera;
    [SerializeField] private ParticleSystem MuzzleFlash;
    [SerializeField] private GameObject ImpactEffect;


    private float GunDamage = 10f;
    private float GunRange = 100f;
    private float ImpactForce = -30f;
    private float FireRate = 15f;
    private float NextTimeToFire = 0f;

    void Update()
    {
        if (Input.GetButton("Fire1") && Time.time >= NextTimeToFire)
        {
            NextTimeToFire = Time.time + 1f / FireRate;
            Fire();
        }
    }

    private void Fire()
    {
        if(Time.timeScale == 1)
        {
            MuzzleFlash.Play();
            RaycastHit hit;

            if (Physics.Raycast(PlayerCamera.transform.position, PlayerCamera.transform.forward, out hit, GunRange))
            {
                Debug.Log(hit.transform.name);
                Target target = hit.transform.GetComponent<Target>();
                BossCube bossCube = hit.transform.GetComponent<BossCube>();

                if (target != null)
                {
                    target.TakeDamage(GunDamage);
                }

                if (bossCube != null)
                {
                    bossCube.BossTakeDamage(GunDamage);
                }

                if (hit.rigidbody != null)
                {
                    hit.rigidbody.AddForce(hit.normal * ImpactForce);
                }

                GameObject impactGO = Instantiate(ImpactEffect, hit.point, Quaternion.LookRotation(hit.normal));
                Destroy(impactGO, 2f);
            }
        }
    }
}
