﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuControl : MonoBehaviour
{
    private GameObject MenupPanel;
    private GameObject CreditsPanel;
    private Button CreditsButton;
    private Button PlayButton;
    private Button BackButton;
    private Button QuitButton;
    private Button InfoButton;
    private GameObject InfoPanel;
    private Button BackButton_2;


    private void Awake()
    {
        MenupPanel = GameObject.FindWithTag("menupanel");
        CreditsPanel = GameObject.FindWithTag("creditspanel");
        CreditsButton = GameObject.Find("CreditsButton").GetComponent<Button>();
        PlayButton = GameObject.Find("PlayButton").GetComponent<Button>();
        BackButton = GameObject.Find("BackButton").GetComponent<Button>();
        QuitButton = GameObject.Find("QuitButton").GetComponent<Button>();
        InfoPanel = GameObject.Find("InfoPanel");
        InfoButton = GameObject.Find("InfoButton").GetComponent<Button>();
        BackButton_2 = GameObject.Find("BackButton_2").GetComponent<Button>();
    }

    private void Start()
    {
        MenupPanel.SetActive(true);
        CreditsPanel.SetActive(false);

        CreditsButton.onClick.AddListener(OpenCreditsPanel);
        BackButton.onClick.AddListener(CloseCreditsPanel);
        PlayButton.onClick.AddListener(Play);
        QuitButton.onClick.AddListener(Quit);
        InfoButton.onClick.AddListener(Info);
        BackButton_2.onClick.AddListener(BackMenu);
    }

    private void OpenCreditsPanel()
    {
        CreditsPanel.SetActive(true);
        MenupPanel.SetActive(false);
    }
    private void CloseCreditsPanel()
    {
        MenupPanel.SetActive(true);
        CreditsPanel.SetActive(false);
    }
    private void Play()
    {
        SceneManager.LoadScene("Level01");
    }
    private void Info()
    {
        InfoPanel.SetActive(true);
        MenupPanel.SetActive(false);
    }
    private void BackMenu()
    {
        InfoPanel.SetActive(false);
        MenupPanel.SetActive(true);
    }
    private void Quit()
    {
        Application.Quit();
    }
}
