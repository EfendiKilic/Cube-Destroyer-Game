﻿using UnityEngine;

public class Target : MonoBehaviour
{
    private float health = 50f;

    public void TakeDamage(float amounth)
    {
        health -= amounth;
        if(health <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        Destroy(gameObject);
    }
}
