﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFlip : MonoBehaviour
{

    [SerializeField] private Transform playerBody;
    private float MouseSensitivity = 100f;
    private float xAxisRotation = 0f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void LateUpdate()
    {
        Flip();
    }

    private void Flip()
    {
        if(Time.timeScale == 1)
        {
            float xMouseAxis = Input.GetAxis("Mouse X") * MouseSensitivity * Time.fixedDeltaTime;
            float yMouseAxis = Input.GetAxis("Mouse Y") * MouseSensitivity * Time.fixedDeltaTime;

            xAxisRotation -= yMouseAxis;
            xAxisRotation = Mathf.Clamp(xAxisRotation, -70f, 70f);

            transform.localRotation = Quaternion.Euler(xAxisRotation, 0f, 0f);
            playerBody.Rotate(Vector3.up * xMouseAxis);
        }
    }

}
