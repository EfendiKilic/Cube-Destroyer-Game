﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossCube : MonoBehaviour
{
    public float health = 1000f;

    public void BossTakeDamage(float amounth)
    {
        health -= amounth;
        if (health <= 0)
        {
            BossDie();
        }
    }

    private void BossDie()
    {
        Destroy(gameObject);
    }
}
