﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour
{

    [SerializeField] private CharacterController PlayerControler;
    [SerializeField] private Transform GroundCheck;
    [SerializeField] private LayerMask GroundMask;
    [SerializeField] private GameObject Parkour;
    [SerializeField] private GameObject MapOneTotal;
    [SerializeField] private GameObject FinalFight;

    private GameObject GameoverPanel;
    private Button RestartButton;
    private Button MenuButton;
    private GameObject PausePanel;
    private Button ResumeButton;
    private Button MenuButton_2;
    private Button CloseButton;
    private GameObject WinPanel;
    private Button CloseButton_2;
    private Button MenuButton_3;

    private BossCube BossHealth;
    private float PlayerSpeed = 12f;
    private float PlayerActGravity = -21.582f;
    private float GroundDistance = 0.4f;
    private float JumpPower = 3f;
    private bool isGrounded;
    private Vector3 InputVelocity;

    private void Awake()
    {
        GameoverPanel = GameObject.FindWithTag("gopanel");
        RestartButton = GameObject.Find("RestartButton").GetComponent<Button>();
        MenuButton = GameObject.Find("MenuButton").GetComponent<Button>();
        PausePanel = GameObject.FindWithTag("pausepanel");
        ResumeButton = GameObject.Find("ResumeButton").GetComponent<Button>();
        MenuButton_2 = GameObject.Find("MenuButton_2").GetComponent<Button>();
        CloseButton = GameObject.Find("CloseButton").GetComponent<Button>();
        WinPanel = GameObject.Find("WinPanel");
        CloseButton_2 = GameObject.Find("CloseButton_2").GetComponent<Button>();
        MenuButton_3 = GameObject.Find("MenuButton_3").GetComponent<Button>();
    }

    private void Start()
    {
        GameoverPanel.SetActive(false);
        PausePanel.SetActive(false);
        WinPanel.SetActive(false);
        RestartButton.onClick.AddListener(Restart);
        MenuButton.onClick.AddListener(GoMenu);
        ResumeButton.onClick.AddListener(Resume);
        MenuButton_2.onClick.AddListener(ReturnMenu);
        CloseButton.onClick.AddListener(Close);
        CloseButton_2.onClick.AddListener(Close);
        MenuButton_3.onClick.AddListener(ReturnMenu);
        BossHealth = GameObject.Find("BossCube").GetComponent<BossCube>();
    }

    private void Update()
    {
        PlayerMovements();
        WinControl();
    }

    private void WinControl()
    {
        if (BossHealth.health == 0)
        {
            WinPanel.SetActive(true);
            Time.timeScale = 0f;
            Cursor.lockState = CursorLockMode.None;
            BossHealth.health = -5;
        }
    }

    private void PlayerMovements()
    {
        if (Input.GetKeyDown(KeyCode.P))
        {
            Time.timeScale = 0f;
            PausePanel.SetActive(true);
            Cursor.lockState = CursorLockMode.None;
        }

        isGrounded = Physics.CheckSphere(GroundCheck.position, GroundDistance, GroundMask);

        if (isGrounded && InputVelocity.y < 0)
        {
            InputVelocity.y = -2f;
        }

        float xInputAxis = Input.GetAxis("Horizontal");
        float zInputAxis = Input.GetAxis("Vertical");

        Vector3 PlayerMovement = transform.right * xInputAxis + transform.forward * zInputAxis;

        PlayerControler.Move(PlayerMovement * PlayerSpeed * Time.deltaTime);

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            InputVelocity.y = Mathf.Sqrt(JumpPower * -2f * PlayerActGravity);
        }

        InputVelocity.y += PlayerActGravity * Time.deltaTime;
        PlayerControler.Move(InputVelocity * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.layer == 9)
        {
            Debug.Log("Anahtar başarılı bir şekilde alındı");
            Destroy(other.gameObject, 1f);
            Parkour.SetActive(true);
        }
        if(other.gameObject.layer == 10)
        {
            Debug.Log("Boss fight başladı");
            Debug.Log("Geri dönüş kapandı");
            Destroy(other.gameObject, 0.5f);
            Destroy(Parkour);
            Destroy(MapOneTotal);
            FinalFight.SetActive(true);
        }
        if(other.gameObject.layer == 11)
        {
            Die();
        }
    }

    private void Die()
    {
        StartCoroutine(Wait());
        GameoverPanel.SetActive(true);
        Cursor.lockState = CursorLockMode.None;
    }
    IEnumerator Wait()
    {
        yield return new WaitForSecondsRealtime(2f);
        Time.timeScale = 0f;
    }

    private void Restart()
    {
        SceneManager.LoadScene("Level01");
        Time.timeScale = 1f;
    }
    private void GoMenu()
    {
        SceneManager.LoadScene("Menu");
    }
    private void Resume()
    {
        PausePanel.SetActive(false);
        Cursor.lockState = CursorLockMode.Locked;
        Time.timeScale = 1f;
    }
    private void ReturnMenu()
    {
        SceneManager.LoadScene("Menu");
        Cursor.lockState = CursorLockMode.None;
        Time.timeScale = 1f;
    }
    private void Close()
    {
        Application.Quit();
    }
}
